<?php
$sk["DB_HOST"] = "localhost";
$sk["DB_USER"] = "tridimed_scriptgratis";
$sk["DB_PASS"] = "tridimed_scriptgratis";
$sk["DB_NAME"] = "tridimed_scriptgratis";
        